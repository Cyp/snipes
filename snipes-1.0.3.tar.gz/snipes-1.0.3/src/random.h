#ifndef RANDOM_H_
#define RANDOM_H_

void seedr(unsigned int);
unsigned int rnd();
unsigned int rndr(unsigned int);

#endif //RANDOM_H_
