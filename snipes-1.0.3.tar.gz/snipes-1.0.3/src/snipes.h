#ifndef SNIPES_H_
#define SNIPES_H_

void cleanupSnipes();
void tickgame();

#endif //SNIPES_H_
