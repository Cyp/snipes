#ifndef HELP_H_
#define HELP_H_

void renderHelp(unsigned char *disp, int width, int height);

#endif //HELP_H_
