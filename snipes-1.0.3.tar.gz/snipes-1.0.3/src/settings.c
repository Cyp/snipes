#include "settings.h"


int curcols = 0;
int saidtoquit = 0;
int lcurd[18];
int newmode=-1;
int initialHelp = 0;

unsigned char disp[80*60];
