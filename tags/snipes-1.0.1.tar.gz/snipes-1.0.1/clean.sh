rm bin2h
rm bitms.h
rm snipes
